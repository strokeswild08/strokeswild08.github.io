Wild Strokes — Copper courier

64 x 64 pixel cells. 8 columns x 8 action rows. 64 frames.
PNG sheet: transparent, no margin or padding. Ground pivot: (32, 60).
Read the JSON for rectangles, FPS and whether an action loops.
Row order: Idle, Walk, Run, Jump, Attack, Hurt, Roll, Celebrate.
Action GIFs are 4x previews; use the original PNG in your game.
Attack, hurt, jump and roll play once; other actions loop.
The character faces right. Mirror horizontally for left-facing sprites.
Art and procedural source: Wild Strokes / Flipbook.
