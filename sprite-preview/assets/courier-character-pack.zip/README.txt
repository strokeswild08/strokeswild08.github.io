Wild Strokes — Copper courier

96 x 96 pixel cells. 8 columns x 8 rows. 64 frames.
Transparent PNG, no margin or padding. Ground pivot: (48, 88).
Read the JSON for frame rectangles, FPS, durations and loop flags.
Rows: Idle, Walk, Run, Jump, Attack, Hurt, Roll, Celebrate.
PNG and JSON are the game assets. GIFs are 4x presentation previews.
Jump, attack, hurt and roll play once; other actions loop.
The character faces right. Mirror horizontally to face left.
The forest scene is a workbench backdrop, excluded from asset exports.
Artwork and editable procedural source: Wild Strokes / Flipbook.
